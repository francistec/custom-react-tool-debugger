# Json Text Difference

- ![#27ae60](https://placehold.it/15/27ae60/000000?text=+) `New element`
- ![#e67e22](https://placehold.it/15/e67e22/000000?text=+) `Updated element`
- ![#c0392b](https://placehold.it/15/c0392b/000000?text=+) `Removed element`

![Json difference](https://knil.gq/img/json-diff-text.png)